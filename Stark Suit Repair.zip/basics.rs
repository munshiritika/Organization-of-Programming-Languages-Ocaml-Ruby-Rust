/**
    Returns the sum 1 + 2 + ... + n
    If n is less than 0, return -1
**/
pub fn gauss(n: i32) -> i32 {
  let mut sum = 0;
    if n < 0{
        sum = -1;
    } 
    else{
        for i in 1..(n+1) {
            sum = sum + i;
        } 
    }        
    return sum;
}

/**
    Returns the number of elements in the list that 
    are in the range [s,e]
**/
pub fn in_range(ls: &[i32], s: i32, e: i32) -> i32 {
    let mut counter = 0;
    for &i in ls.iter(){
        if i >= s && i <= e{
            counter = counter + 1;
        }
    } /** end for loop **/
    return counter;
} /** end function **/

/**
    Returns true if target is a subset of set, false otherwise

    Ex: [1,3,2] is a subset of [1,2,3,4,5]
**/
pub fn subset<T: PartialEq>(set: &[T], target: &[T]) -> bool {
    let mut counter = 0;
    for i in set.iter(){
        for j in target.iter(){
            if i == j{
                counter = counter + 1;
            }
        }
    }
    if counter == target.len(){
        return true;
    }
    return false;
}

/**
    Returns the mean of elements in ls. If the list is empty, return None
    It might be helpful to use the fold method of the Iterator trait
**/
pub fn mean(ls: &[f64]) -> Option<f64> {
    let mut sum = 0.0;
    let mut avg = 0.0;
    if ls.len() == 0{
        return None;
    }
    for &i in ls.iter(){
        sum = sum + i;
    }
    avg = sum/f64::from(ls.len() as i32);
    return Some(avg);
}

/**
    Converts a binary number to decimal, where each bit is stored in order in the array
    
    Ex: to_decimal of [1,0,1,0] returns 10
    2^(*0)+2^(1*1)+2^2+2^3
**/
pub fn to_decimal(ls: &[i32]) -> i32 {
    let mut value = 0;
    let base: i32 = 2;
    let mut leng = ls.len() as u32;
    for i in ls.iter(){
        leng = leng-1; 
        value = value + (i * (base.pow(leng)));
    }
    return value;
}

/**
    Decomposes an integer into its prime factors and returns them in a vector
    You can assume factorize will never be passed anything less than 2

    Ex: factorize of 36 should return [2,2,3,3] since 36 = 2 * 2 * 3 * 3
**/
pub fn factorize(n: u32) -> Vec<u32> {
    let mut value = Vec::new();
    let mut number = n;
    for i in 2..number{
        while number % i == 0{
            value.push(i);
            number = number/i;
        }
    }
    if number > 1{
        value.push(number);
    }
    return value;
}

/** 
    Takes all of the elements of the given slice and creates a new vector.
    The new vector takes all the elements of the original and rotates them, 
    so the first becomes the last, the second becomes first, and so on.
    
    EX: rotate [1,2,3,4] returns [2,3,4,1]
**/
pub fn rotate(lst: &[i32]) -> Vec<i32> {
     let mut value = Vec::new();
    if lst.is_empty() {
        return value;
    }
     for i in lst.iter() {
         value.push(*i);
     }

    // let n = lst.len() as i32;
    // if n == 1{
    //     value.push(lst[0]);
    //     return value;
    // }
    // value.push(lst[1]);
    // for i in 2..n{
    //     value.push(lst[i as usize]);    
    // }
    // value.push(lst[0]);
    // return value;
    value.rotate_left(1);
    return value;
    
}

/**
    Returns true if target is a subtring of s, false otherwise
    You should not use the contains function of the string library in your implementation
    
    Ex: "ace" is a substring of "rustacean"
**/
pub fn substr(s: &String, target: &str) -> bool {
    for i in 0..=(s.len()){
        for j in 0..=(s.len()){            
            if j >= i && s[i..j] == *target{
                return true; 
            }
        }
    }
    return false;
}

/**
    Takes a string and returns the first longest substring of consecutive equal characters

    EX: longest_sequence of "ababbba" is Some("bbb")
    EX: longest_sequence of "aaabbb" is Some("aaa")
    EX: longest_sequence of "xyz" is Some("x")
    EX: longest_sequence of "" is None
**/
pub fn longest_sequence(s: &str) -> Option<&str> {
    if s == ""{
        return None;
    }
    let ss: Vec<char> = s.chars().collect();
    let mut temp_start = 0;
    let mut count = 1;
    let mut track = 0;
    let mut final_start = 0;
    let mut val = "";
   
    
    for i in 1..(ss.len()){
        if ss[i-1] == ss[i]{
            count = count + 1;
        }
       else{
            temp_start = i;
            count = 1;
       }
       if count > track{
            final_start = temp_start;
            track = count;
         }
       }
       val = &s[final_start..final_start + track];
    
    return Some(val);

    
}
