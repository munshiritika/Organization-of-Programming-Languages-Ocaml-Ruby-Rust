use std::convert::TryFrom;

#[derive(Debug)]
#[derive(PartialEq)]
pub enum Command
{
    Power(bool,i32),    // [Increase/Decrease] power by [number].
    Missiles(bool,i32), // [Increase/Decrease] missiles by [number].
    Shield(bool),       // Turn [On/Off] the shield.
    Try,                // Try calling pepper.
    Invalid             // [anything else]
}


/**
    Adds functionality to Command enums
    Commands can be converted to strings with the as_str method
    
    Command     |     String format
    ---------------------------------------------------------
    Power       |  /Power (increased|decreased) by [0-9]+%/
    Missiles    |  /Missiles (increased|decreased) by [0-9]+/
    Shield      |  /Shield turned (on|off)/
    Try         |  /Call attempt failed/
    Invalid     |  /Not a command/
**/
impl Command {
    pub fn as_str (&self) -> String {
       match self {
        &Command::Power (bol, inte) => if bol == true{ 
                                                    String::from("Power increased by ") + &inte.to_string() + &String::from("%")
                                                } else {
                                                    String::from("Power decreased by ") + &inte.to_string() + &String::from("%")
                                                },
        &Command::Missiles (bol, inte) => if bol == true{ 
                                                    String::from("Missiles increased by ") + &inte.to_string() //+ &String::from("%")
                                                } else {
                                                    String::from("Missiles decreased by ") + &inte.to_string() //+ &String::from("%")
                                                },
        &Command::Shield (bol) => if bol == true{ 
                                            String::from("Shield turned on")
                                        } else {
                                            String::from("Shield turned off")
                                        },
                                       
        Command::Try => String::from("Call attempt failed"),
        Command::Invalid => String::from("Not a command"),
       }
    }
}

/**
    Complete this method that converts a string to a command 
    We list the format of the input strings below

    Command     |     String format
    ---------------------------------------------
    Power       |  /power (inc|dec) [0-9]+/
    Missiles    |  /(fire|add) [0-9]+ missiles/
    Shield      |  /shield (on|off)/
    Try         |  /try calling Miss Potts/
    Invalid     |  Anything else
**/
pub fn to_command(s: &str) -> Command {
    let mut com = Command::Invalid;    
    let str: Vec<&str> = s.split_whitespace().collect();
    
     
    if str.len() == 3 { //power and missiles will be length 3
        //power
        if str[0] == "power" {
            if str[1] == "inc" || str[1] == "add" || str[1] == "on" {
                if str[2].parse::<i32>().is_ok() {
                    let value: i32 = str[2].parse().unwrap(); 
                    com = Command::Power (true, value);
                }
            } else if str[1] == "dec" || str[1] == "fire" || str[1] == "off" {
                if str[2].parse::<i32>().is_ok() {
                    let value: i32 = str[2].parse().unwrap(); 
                    com = Command::Power (false, value);
                }
   
            }
        }
        //missiles
        else if str[0] == "inc" || str[0] == "add" || str[0] == "on"{
            if str[1].parse::<i32>().is_ok()  {
                if str[2] == "missiles" {
                    let value: i32 = str[1].parse().unwrap(); 
                    com = Command::Missiles (true, value);
                }
            } 
        } else if str[0] == "dec" || str[0] == "fire" || str[0] == "off" {
            if str[1].parse::<i32>().is_ok()  {
                  if str[2] == "missiles"{
                    let value: i32 = str[1].parse().unwrap(); 
                    com = Command::Missiles (false, value);
                  }
              }         
        }
   
    }

    else if str.len() == 2 { //shield has length 2
        //shield
        if str[0] == "shield" {
            if str[1] == "inc" || str[1] == "add" || str[1] == "on" {
                    com = Command::Shield (true);
            } else if str[1] == "dec" || str[1] == "fire" || str[1] == "off" {
                   com = Command::Shield (false);
            }
        }
    }     
    else if str.len() == 4 { //length is not 2 or 3 then it is try or else invalid
        //try
        if str[0] == "try" {
            com = Command::Try;
        } 
    }

    //invalid
    else {
        com = Command::Invalid;
    }
    
   


    // if s.contains("power") || s.contains("Power") {
    //     if s.contains("inc") || s.contains("add") || s.contains("on"){
    //         com =  Command::Power (true, 0); //(true, value);
    //     }
    //     else if s.contains("dec") || s.contains("off") || s.contains("fire"){
    //         com =  Command::Power (false, 0); //(false, value);
    //     }
    // }

    // else if s.contains("missiles") || s.contains("Missiles") {
    //     if s.contains("inc") || s.contains("add") || s.contains("on"){
    //         com =  Command::Missiles (true, 0);//(true, value);
    //     }
    //     else if s.contains("dec") || s.contains("off") || s.contains("fire"){
    //         com =  Command::Missiles (false, 0);//(false, value);
    //     }
    // }

    // else if s.contains("shield") || s.contains("Shield") {
    //     if s.contains("inc") || s.contains("add") || s.contains("on"){
    //         com =  Command::Shield (true);
    //     }
    //     else if s.contains("dec") || s.contains("off") || s.contains("fire"){
    //         com =  Command::Shield (false);
    //     }
    // } 

    // else if s.contains("try") || s.contains("Try") {
    //     com =  Command::Try;
    // }

    // else {
    //     com =  Command::Invalid;
    // } 

    return com;

    
}
