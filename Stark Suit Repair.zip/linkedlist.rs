use std::{
    borrow::BorrowMut,
    ops::{Deref, DerefMut},
    sync::{Arc, RwLock},
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Component {
    Helmet(bool),              //is damaged?
    LeftThrusters(bool, i32),  //is damaged? How much power left?
    RightThrusters(bool, i32), //is damaged? How much power left?
    LeftRepulsor(bool, i32),   //is damaged? How much power left?
    RightRepulsor(bool, i32),  //is damaged? How much power left?
    ChestPiece(bool, i32),     //is damaged? How much power left?
    Missiles(i32),             //how many missiles left?
    ArcReactor(i32),           // How much power left?
    Wifi(bool),                // connected to wifi?
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Armor {
    pub component: Component,
    pub version: i32,
}

// Part 2

// Students should fill in the Link type themselves. The Node and List types are given as is.
type Link =  Option<Arc<RwLock<Node>>>;

struct Node {
    data: Armor,
    rest: Link,
}

#[derive(Clone)]
pub struct List {
    head_link: Link,
    size: usize,
}

impl List {
    pub fn new() -> Self { 
        List {
            head_link: None,
            size: 0,
        }
    }

    pub fn size(&self) -> usize {
        self.size
    }

    pub fn peek(&self) -> Option<Armor> {
        
        match &(self.head_link) {
            Some (h) => Some (h.read().unwrap().data.clone()),
            None => None,
        }
    }

    pub fn push(&mut self, component: Armor) {
       let n = Node {
            data: component,
            rest: self.head_link.take(),
        };
        self.head_link = Some (Arc::new (RwLock::new (n)));
    }

    pub fn pop(&mut self) -> Option<Armor> {
      
        match &(self.head_link.take()) {
          
            Some (h) => {self.head_link =  h.read().unwrap().rest.clone(); Some (h.read().unwrap().data)},
            None => None,
        }
    }

}



// Part 3

#[derive(Clone)]
pub struct Suit {
    pub armor: List,
    pub version: i32,
}

impl Suit {
    pub fn is_compatible(&self) -> bool {
        let mut l = self.armor.clone(); //creating a copy of the list of armor     
        while l.peek() != None { //would loop until it finds the version
           let mut armor_val = l.peek().unwrap();
            if armor_val.version != self.version {  //if it finds the version would make flag as true
                return false;
            }//end if statement
           l.pop();
        }//end while loop
        return true;
    } //end function



    pub fn repair(&mut self) {
       let mut copy_list = self.armor.clone();
        //headlink = copy_list.head_link;
       while copy_list.peek() != None {
           
            let val_from_armour = &copy_list.head_link.clone().unwrap(); //new pointer to head of list, some unwrap
            let mut val_from_armour = val_from_armour.try_write().unwrap(); 

            match &mut val_from_armour.data.component {
                Component::LeftThrusters (a,b) => if *a == true {*a = false; *b = 100;},
                Component::RightThrusters (a,b) => if *a == true {*a = false; *b = 100;},
                Component::LeftRepulsor (a,b) => if *a == true {*a = false; *b = 100;},
                Component::RightRepulsor (a,b) => if *a == true {*a = false; *b = 100;},
                Component::ChestPiece (a,b) =>  if *a == true {*a = false; *b = 100;},
                _ => {},
            }//end match
            drop(val_from_armour);
            copy_list.pop();
        }//end while   
    }//end funtion

}