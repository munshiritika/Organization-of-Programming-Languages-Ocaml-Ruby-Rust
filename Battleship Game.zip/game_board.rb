#Name: Ritika Munshi
#UID: 118345048

class GameBoard
    # @max_row is an `Integer`
    # @max_column is an `Integer`
    attr_reader :max_row, :max_column

    def initialize(max_row, max_column)
        @max_row = max_row  
        @max_column = max_column

        #created a 2-D Array with initializing values as '-' instead of nil as per the example in the description
        @gameboard_array = Array.new(@max_row){Array.new(@max_column, '-')} 
        #tracking the successful attacks
        @attack_tracking = 0
        #tracking the overall size of the ships
        @size_track = 0

    end

    # adds a Ship object to the GameBoard
    # returns Boolean
    # Returns true on successfully added the ship, false otherwise
    # Note that Position pair starts from 1 to max_row/max_column
    def add_ship(ship)
        counter = 0                                                #counter for the ships
        #storing the variables from ship into different variables for easy to access
        row_position_ship = ship.start_position.row                #row of the position of the ship
        column_position_ship = ship.start_position.column          #column of the position of the ship
        orientation_ship = ship.orientation                        #orientation or direction of ship
        size_ship = ship.size                                      #size of the ship

        #checking out of bounds for each orientation or direction with the size and position of the ships
        if (orientation_ship.eql?("Up"))                           #if the direction is Up
            if (row_position_ship - size_ship < 1)                 #if row - size less than 1
                return false
            end
        elsif (orientation_ship.eql?("Down"))                      #if the direction is Down
            if (row_position_ship + size_ship - 1 > max_row)       #if row + size greater than max_row
                return false
            end
        elsif (orientation_ship.eql?("Right"))                     #if the direction is Right
            if (column_position_ship + size_ship - 1 > max_column) #if column + size greater than max_column
                return false
            end
        elsif (orientation_ship.eql?("Left"))                      #if the direction is Left
            if (column_position_ship - size_ship < 1)              #if column - size less than 1
                return false
            end
        else
            return false                                           #if none of the direction appliesl return false
        end

        #checking if they overlap via iterating and checking until my counter is less than the size of the ship
        for counter in 0...size_ship
            #check if that position does not have a ship, return false
            if (@gameboard_array[row_position_ship - 1][column_position_ship - 1] != '-')
                return false
            end
            #checking with orientation for the size of the ship and incrementing/decrementing accordingly
            if (orientation_ship.eql?("Up"))                       #if the direction is Up
                row_position_ship = row_position_ship - 1          #decrement the row by 1
            elsif (orientation_ship.eql?("Down"))                  #if the direction is Down
                row_position_ship = row_position_ship + 1          #increment the row by 1            
            elsif (orientation_ship.eql?("Right"))                 #if the direction is Right
                column_position_ship = column_position_ship + 1    #increment the column by 1
            elsif (orientation_ship.eql?("Left"))                  #if the direction is Left
                column_position_ship = column_position_ship -1     #decrement the column by 1
            end
            #increment the counter when a ship is found for a particular size
            counter = counter + 1
        end

        #reseting the counter, row and column as for every ship we work with everytime
        counter = 0
        row_position_ship = ship.start_position.row                #row of the position of the ship
        column_position_ship = ship.start_position.column          #column of the position of the ship

        #actually adding to the ship by iterating until counter is less than size of the ship
        for counter in 0...size_ship
            #as we add a ship we are adding by 'B' as following the example
            @gameboard_array[row_position_ship - 1][column_position_ship - 1] = 'B' 
            
            #checking with orientation for each grid while adding with following the size of the ship
            if (orientation_ship.eql?("Up"))                       #if the direction is Up
                row_position_ship = row_position_ship - 1          #decrement the row by 1
            elsif (orientation_ship.eql?("Down"))                  #if the direction is Down
                row_position_ship = row_position_ship + 1          #increment the row by 1       
            elsif (orientation_ship.eql?("Right"))                 #if the direction is Right
                column_position_ship = column_position_ship + 1    #increment the column by 1
            elsif (orientation_ship.eql?("Left"))                  #if the direction is Left
                column_position_ship = column_position_ship - 1    #decrement the column by 1
            end
            #tracking the size of the ship for overall
            @size_track += 1                                       #increment the size of overall ship by 1
            #increment the counter by 1 for the ships as we add
            counter = counter + 1
        end

        return true
    end

    # return Boolean on whether attack was successful or not (hit a ship?)
    # return nil if Position is invalid (out of the boundary defined)
    def attack_pos(position)
        #check if the start_position row and column is greater than the max_row & max_column; return false
        if(position.row > max_row || position.column > max_column)
            return nil
        end
        #check if the start_position row and column is less than 1; return false
        if(position.row < 1 || position.column < 1)
            return nil
        end

        # if the attack was not successful when it does not find a ship; return false
        if (@gameboard_array[position.row - 1][position.column - 1] == '-')
            return false
        end

        #updating the grid
        #when attack was done successfully by finding the ship at that position; track the attack
        @attack_tracking = @attack_tracking + 1
        #when attack was done successfully by finding the ship at that position; make change to that position of the ship
        #updating the grid by 'A' as per the example and description where the attack is successfully made
        @gameboard_array[position.row - 1][position.column - 1] = 'A'

        return true
    end

    # Number of successful attacks made by the "opponent" on this player GameBoard
    def num_successful_attacks
        #returning the number of successful attacks via the attack_pos method that we tracked while updating the grid
        return @attack_tracking
    end

    # returns Boolean
    # returns True if all the ships are sunk.
    # Return false if at least one ship hasn't sunk.
    def all_sunk?
        #if the size of the ship that we were tracking as we were adding equals the total number of successful attacks; denotes that it is sunked
        if (@size_track <= @attack_tracking)  
            return true
        end

        return false
    end

    # String representation of GameBoard (optional but recommended)
    def to_s
        #looping/iterating over the 2-D array created to print
        for i in @gameboard_array
            for j in i
                print j
            end
            puts ("")
        end
        #"STRING METHOD IS NOT IMPLEMENTED"
    end

end
