#Name: Ritika Munshi
#UID: 118345048

require_relative '../models/game_board'
require_relative '../models/ship'
require_relative '../models/position'

# return a populated GameBoard or nil
# Return nil on any error (validation error or file opening error)
# If 5 valid ships added, return GameBoard; return nil otherwise

def read_ships_file(path)
    GameBoard.new 10, 10

    gameboard = GameBoard.new(10, 10)
    @count_5_ships = 0 #count the number of valid lines or ships from the file

    File.foreach(path) do |line|
        if (line =~ /^\(([0-9]+),([0-9]+)\), ([A-Z][a-z]+), ([0-9]+)$/)
            #check if according to the line we get from file, if add_ship method return true which states its valid
            if(gameboard.add_ship(Ship.new(Position.new($1.to_i, $2.to_i), $3, $4.to_i)) == true)
                #increment the counter when the valid line/ship is found
                @count_5_ships += 1 
            end
            #if 5 valid ships are found from the file; return the gameboard
            if(@count_5_ships == 5)
                return gameboard
            end
        end
    end

    #if there weren't 5 valid ships to be added return nil
    return nil
end


# return Array of Position or nil
# Returns nil on file open error
def read_attacks_file(path)
    [Position.new(1, 1)]

    game_board = GameBoard.new(10, 10)

    #check if the file exist, if it does not return nil
    if(File.exist?(path) == false)
        return nil
    end

    position_array = Array.new #created a new array

    File.foreach(path) do |line|
        #(number,number)
        if (line =~ /^\(([0-9]+),([0-9]+)\)$/) #check if found as per the correct format                      
            position_array.push(Position.new($1.to_i,$2.to_i)) #if found; push/store them in array
        end
    end

    return position_array
end


# ===========================================
# =====DON'T modify the following code=======
# ===========================================
# Use this code for reading files
# Pass a code block that would accept a file line
# and does something with it
# Returns True on successfully opening the file
# Returns False if file doesn't exist
def read_file_lines(path)
    return false unless File.exist? path
    if block_given?
        File.open(path).each do |line|
            yield line
        end
    end

    true
end
