(*Name: Ritika Munshi
  UID: 118345048
*)

open List
open Sets

(*********)
(* Types *)
(*********)

type ('q, 's) transition = 'q * 's option * 'q

type ('q, 's) nfa_t = {
  sigma: 's list;
  qs: 'q list;
  q0: 'q;
  fs: 'q list;
  delta: ('q, 's) transition list;
}

(***********)
(* Utility *)
(***********)

(* explode converts a string to a character list *)
let explode (s: string) : char list =
  let rec exp i l =
    if i < 0 then l else exp (i - 1) (s.[i] :: l)
  in
  exp (String.length s - 1) []

(****************)
(* Part 1: NFAs *)
(****************)

(*helper for move*)
let rec move_helper (delta: ('q * 's option * 'q) list ) (q: 'q) (s: 's option) : 'q list = 
match delta with
| [] -> []
| h :: t -> match h with                              (*match over h because every element is a tuple and every tuple has three elements*)
            | (a,b,c) -> if (q = a && b = s)          (*if they match then we would put them in the list*)
                          then c :: move_helper t q s
                        else 
                          move_helper t q s           (*if they dont then we would do a recursive call over the helper function for move*)
                                    
  
let rec move (nfa: ('q,'s) nfa_t) (qs: 'q list) (s: 's option) : 'q list =
  match qs with                                                (*match over the qs list*)
  | [] -> []                                                   (*return an empty list if the input is an empty list*)
  | h :: t -> union (move_helper nfa.delta h s) (move nfa t s) (*or else using union function until it gets to the end of the list*)


(*helper for e_closure*)
let rec closure_helper (nfa: ('q,'s) nfa_t) (processed: 'q list) (about_process: 'q list) : 'q list = 
    match about_process with
    | [] -> processed
    | h :: t -> if ((elem h processed) = true) then closure_helper nfa processed t (*if h is already processed then ignore that*)
                else 
                  closure_helper nfa (h::processed) (union (move nfa [h] None) t)  (*if h is not process we have to include that to process*)

let rec e_closure (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list =
  closure_helper nfa [] qs (*calling the hellper function so that it goes over each and every state*)

(*
let rec closure_helper (nfa: ('q,'s) nfa_t) (q: 'q list) (q': 'q list) : 'q list = 
  let q = q' in                         (*Let R = R’*)
  let q' = union q (move nfa q None) in (*Let R’ = R È {q | p Î R, (p, e, q) Î d} : new ε-reachable states*)
  if(q <> q')                           (* if R != R’*)
   then closure_helper nfa q q'         (*then recursive call over the helper function until R = R’: stop when no new states*)
  else q
  (*
    if (eq q q')                           
    then q        
    else closure_helper nfa q q'
  *)

let rec e_closure (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list =
  let qs' = qs in           (*Let R’= R : start states*)
  closure_helper nfa qs qs' (*calling the hellper function so that it goes over each and every state*)
*)

(*helper for accept*)
let rec accept_helper (nfa: ('q,char) nfa_t) (q: 'q list) (c: char list) : 'q list =
  match c with                                      (*matching over the char list which is basically our sigma*)
  | [] ->  e_closure nfa q                          (*if its an empty list then do an eplison-closure over the q list*)
  | h :: t -> let movess = move nfa q (Some h) in   (*recursive over move*)  
              let close = e_closure nfa movess in   (*recursive over e_closure with the list that move returns*)
              accept_helper nfa close t             (*recursive call over the helper function until it reaches the end of the list*)

let rec accept (nfa: ('q,char) nfa_t) (s: string) : bool = 
    let ss = explode s in                                          (*using explode function*)
    let helper = accept_helper nfa (e_closure nfa [nfa.q0]) ss in  (*calling helper function over the start state which is our q0*)
    List.fold_left(fun acc x -> if ((elem x nfa.fs) = true) then true else acc) false helper

(*******************************)
(* Part 2: Subset Construction *)
(*******************************)

let new_states (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list list =
  (*s_sigma = nfa.sigma holds the characters we are iterating over*)
   List.fold_left(fun accumulator s_sigma -> let mo = move nfa qs (Some s_sigma) in
                                             let e_close = e_closure nfa mo in
                                             e_close :: accumulator) [] nfa.sigma
 
let new_trans (nfa: ('q,'s) nfa_t) (qs: 'q list) : ('q list, 's) transition list =
  (*Example: new_trans dfa_ex [0; 1] = [([0; 1], Some 'a', [1]); ([0; 1], Some 'b', [0]); ([0; 1], Some 'c', [2])]*)
  List.fold_left(fun accumulator s_sigma -> let mo = move nfa qs (Some s_sigma) in
                                            let e_close = e_closure nfa mo in
                                            (qs, (Some s_sigma), e_close) :: accumulator) [] nfa.sigma
  

(*Given an NFA and a DFA state, returns [qs] if qs is final in the DFA and [] otherwise.*)                              
let new_finals (nfa: ('q,'s) nfa_t) (qs: 'q list) : 'q list list =
  let found = List.fold_left(fun accumulator s -> if (elem s nfa.fs) 
                                                    then true 
                                                  else accumulator) false qs in 
                                                  if (found = true) 
                                                    then [qs] 
                                                  else []

(*helper function to not add item in the lists thats already there in the list*)
let unique lst = List.fold_left(fun acc x -> if ((elem x acc) = false) 
                                              then x :: acc 
                                             else acc) [] lst 
(*1;2   1;2;1;2*)
let rec nfa_to_dfa_step (nfa: ('q,'s) nfa_t) (dfa: ('q list, 's) nfa_t)
    (work: 'q list list) : ('q list, 's) nfa_t =
  match work with
  | [] -> dfa
  | h :: t -> if((elem h dfa.qs) = false) then
              let new_qs = (new_states nfa h) in                      (*new states*)
             (* let add_qs = union dfa.qs new_qs in    *)             (*add it to our DFA that we are creating*)
              let update_delta = union dfa.delta (new_trans nfa h) in (*new tansition*)
              let final_fs = union dfa.fs (new_finals nfa h) in       (*new final state*)
              let work_update = union t (minus new_qs dfa.qs) in      (*updating the work list*)
              nfa_to_dfa_step nfa {sigma = dfa.sigma; qs = h::dfa.qs; q0 = e_closure nfa [nfa.q0]; fs = final_fs; delta = update_delta } work_update 
              else
                nfa_to_dfa_step nfa dfa t

let rec nfa_to_dfa (nfa: ('q,'s) nfa_t) : ('q list, 's) nfa_t =
  let start = e_closure nfa [nfa.q0] in                                      (*start state*)
  let dfa = {sigma = nfa.sigma; qs = []; q0 = start; fs = []; delta = []} in (*creating a new dfa*)
  let work = [start] in                                                      (*work is basically a list of list*)
  nfa_to_dfa_step nfa dfa work                                               (*recursive call*)

