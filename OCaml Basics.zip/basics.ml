(* Name: Ritika Munshi
   UID: 118345048
*)

(***********************************)
(* Part 1: Non-Recursive Functions *)
(***********************************)

let rev_tup tup = 
    match tup with (*using pattern matching to reverse the order of the tuple*)
    | (a,b,c) -> (c,b,a)

let is_odd x = 
   if (x mod 2 = 0) (* if its an even return false *)
      then false
   else true (*else return true*)

(* Auxiliary function created to compute absolute values *)
let absolute_aux x = 
   if (x > 0) (*if the value of x is greater than 0 then its a positive number*)
      then x
   else (x * (-1)) (*else we need to take the absolute value to make it a positive number*)

let area x y = 
   match x, y with
   | (a,b),(x,y) -> (absolute_aux(x-a) * absolute_aux(y-b)) (*using the helper function created which is absolute value to compute the area*)
     
let volume x y =
   match x, y with
   | (a,b,c),(x,y,z) -> (absolute_aux(x-a) * absolute_aux(y-b) * absolute_aux(c-z)) (*using the helper function created which is absolute value to compute the volume*)



(*******************************)
(* Part 2: Recursive Functions *)
(*******************************)

let rec fibonacci n =
   if (n <= 1) (*if n is less than or equal to 1; return n itself*)
   then n
   else (fibonacci(n-1)+fibonacci(n-2)) (*else we would recursively call the function fibonacci until it reaches the base case*)

let rec pow x y = 
   if (y = 0) (*if y is 0 then the power of x will be 1*)
   then 1
   else
   x * (pow(x)(y-1)) (*else we will recursively call the power function until y becomes 0*)

let rec log x y = 
   if (y/x = 1) (*if y/x equals 1 then the logarithm of x and y would be 1*)
      then 1
   else if (y/x = 0) (*if y/x equals 0 then the logarithm of x and y would be 0*)
      then 0
   else
     (* if (y/x < x) (* check if that is not a perfect logarithm value we dont add 1 else we add 1 *)
      then (log x (y/x))
      else*)
      (log x (y/x)) + 1  (*else we will call the logarithm of x and y recursively until one of the base cases hit*)


let rec gcf x y = 
   if (y = 0) (* if the second value is 0 then gcf would be the first value itself *)
   then x
   else
   (gcf y (x mod y)) (* checking and computing recursively via divisibility*)

let rec is_prime_helper x n = 
(* x is the number we want to check 
   n is the values it divides to which is between 2 and x *)
   if (n <= 1) (*if n is less than or equal to 1 then return true*)
   then true
   else if (x mod n = 0) (*if the number is divisible by any n then its not a prime number*)
   then false
   else (is_prime_helper x (n-1)) (*else we would recursively call the helper function to find if its prime or not*)

let is_prime x = 
   if (x <= 1) (* any value of x less than equal to 1 is not a prime number *)
   then false
   else is_prime_helper x (x-1) (*calling helper function to know if x is prime number or not*)



(*****************)
(* Part 3: Lists *)
(*****************)

(* Helper function to compute the length of the list *)
let rec length_of_list lst = 
   match lst with
   | [] -> 0 (* if its an empty list, the length would of the list would be 0 *)
   | h :: t -> 1 + length_of_list t (* computes the length of the list recursively if its not empty *)

let rec get idx lst = 
   if (idx > (length_of_list lst)) (* if idx is greater than the length of the list returns an error *)
   then failwith "Out of bounds" 
   else (*else use pattern matching to know the element at the index of the list*)
   match lst with
   | [] -> failwith "Out of bounds" (*if its an empty list we throw an error*)
   | h :: t -> if (idx = 0)  (*if idx = 0 that means its that 1st element which h in the list *)
               then h  
               else get (idx - 1) t (*if idx !=0 then we need to recursilvely call get function until we get that value *)
   

let larger lst1 lst2 = 
   if ((length_of_list lst1) = (length_of_list lst2)) (*if the length of both list is same return empty list *)
   then []
   else if ((length_of_list lst1) > (length_of_list lst2)) (*if list1 length > list2 length return list1 else list2 *)
   then lst1
   else lst2

(* Helper function to append two list into one *)
let rec adding_lists lst1 lst2 = 
   match lst1 with
   | [] -> lst2 (*if list1 is empty then we return the list2*)
   | h::t -> h::(adding_lists t lst2) (*else we recursively concat or combine or append the list1 and list2*)

let rec reverse lst = 
   match lst with
   | [] -> [] (*return empty list for an input of empty list *)
   | h::t -> adding_lists (reverse t) (h::[]) (* using adding_lists recursive function to append or adding the list element to the last of the reversed list *)

let rec combine lst1 lst2 = 
   match lst1 with
   | [] -> lst2 (*if list1 is empty then we return the list2*)
   | (h::t) -> h::(combine t lst2) (*appending or combining two lists together as it is *)

let rec merge lst1 lst2 =    
   match (lst1,lst2) with
   | [],[] -> [] (*if empty lists we return empty list *)
   | [],lst2 -> lst2 (*if list1 is empty we return list2 *)
   | lst1,[] -> lst1 (*if list2 is empty we return list1 *)
   | (p::q, x::y) -> if (p <= x) (*if the value in list1 is less than or equal to list2 *)
                        then p :: (merge q lst2) (*we would merge the value of list1*)
                        else x :: (merge lst1 y) (*else we would merge the value of list2*)        


let rec rotate shift lst = 
  match lst with
   |[] -> [] (* rotating empty list will give empty list no matter whatever the value of shift is *)
   |h::t -> if (shift > 0)
               then rotate (shift-1) (adding_lists t [h]) (*calling adding_lists to concat or append the list as we rotate*)
            else lst
(*
let rec helper_palindrome lst start_index end_index =
   
   if (start_index = end_index)
      then true
   else if ((get start_index lst) = (get end_index lst))
      then true
   else (helper_palindrome lst (start_index+1) (end_index-1))
   *)
let rec is_palindrome lst = 
   
   if ((length_of_list lst) = 0 || (length_of_list lst) = 1) (* when its an empty list or else with just one element return true*)
      then true
   else if ((reverse lst) = (lst)) (*if the reversed list which is recursively happening is same as the list given to check for palindrome; return true*)
      then true
   else
      false (*if none of the above apply; return false*)
   
   (*
   if ((length_of_list lst) = 0 || (length_of_list lst) = 1) 
      then true
   else (helper_palindrome lst (0 + 1) (length_of_list lst - 1)) *)