(*Name: Ritika Munshi
UID: 118345048
*)

open MicroCamlTypes
open Utils
open TokenTypes

(* Provided functions - DO NOT MODIFY *)

(* Matches the next token in the list, throwing an error if it doesn't match the given token *)
let match_token (toks: token list) (tok: token) =
  match toks with
  | [] -> raise (InvalidInputException(string_of_token tok))
  | h::t when h = tok -> t
  | h::_ -> raise (InvalidInputException(
      Printf.sprintf "Expected %s from input %s, got %s"
        (string_of_token tok)
        (string_of_list string_of_token toks)
        (string_of_token h)))

(* Matches a sequence of tokens given as the second list in the order in which they appear, throwing an error if they don't match *)
let match_many (toks: token list) (to_match: token list) =
  List.fold_left match_token toks to_match

(* Return the next token in the token list as an option *)
let lookahead (toks: token list) = 
  match toks with
  | [] -> None
  | h::t -> Some h

(* Return the token at the nth index in the token list as an option*)
let rec lookahead_many (toks: token list) (n: int) = 
  match toks, n with
  | h::_, 0 -> Some h
  | _::t, n when n > 0 -> lookahead_many t (n-1)
  | _ -> None

(* Part 2: Parsing expressions *)

let rec parse_expr toks = match (lookahead toks) with
                        | Some(Tok_Let) -> let_helper toks
                        | Some(Tok_If)  -> if_helper toks
                        | Some(Tok_Fun) -> fun_helper  toks
                        | _ -> or_helper toks

and if_helper toks = let if_matched_toks = match_token toks Tok_If in
                                            let (a,b) = parse_expr if_matched_toks in
                    let then_matched_toks = match_token a Tok_Then in
                                            let (c,d) = parse_expr then_matched_toks in
                    let else_matched_toks = match_token c Tok_Else in
                                            let (e,f) = parse_expr else_matched_toks in
                                            (e, (If (b,d,f)))

and fun_helper toks = let fun_matched_toks = match_token toks Tok_Fun in
                                            match lookahead fun_matched_toks with
                                            |Some (Tok_ID (s)) -> let id_matched_toks = match_token fun_matched_toks (Tok_ID (s)) in
                                                                  let arrow_matched_toks = match_token id_matched_toks Tok_Arrow in
                                                                  let(a,b) = parse_expr arrow_matched_toks in (a, (Fun (s, b)))
                                            | _ -> raise (InvalidInputException("parse_function_expr in fun_helper"))

and or_helper toks = let (a,b) = and_helper_toks toks in
                                 match lookahead a with
                                 | Some Tok_Or -> let c = match_token a Tok_Or in
                                             let (d,e) = or_helper c in
                                             (d, Binop (Or,b,e))
                                 | _ -> a, b

and and_helper_toks toks = let (a,b) = equality_helper toks in
                            match lookahead a with
                            | Some Tok_And -> let c = match_token a Tok_And in
                                        let (d,e) = and_helper_toks c in
                                        (d, Binop (And,b,e))
                            | _ -> a, b                    

and equality_helper toks = let (a,b) = relational_helper toks in
                            match lookahead a with
                            | Some Tok_Equal -> let c = match_token a Tok_Equal in
                                        let (d,e) = equality_helper c in
                                        (d, Binop (Equal,b,e))
                            | Some Tok_NotEqual -> let f = match_token a Tok_NotEqual in
                                        let (g,h) = equality_helper f in
                                        (g, Binop (NotEqual,b,h))           
                            | _ -> a, b

and relational_helper toks = let (a,b) = additive_helper toks in
                            match lookahead a with
                            | Some Tok_Less -> let c = match_token a Tok_Less in
                                        let (d,e) = relational_helper c in
                                        (d, Binop (Less,b,e))
                            | Some Tok_Greater -> let f = match_token a Tok_Greater in
                                        let (g,h) = relational_helper f in
                                        (g, Binop (Greater,b,h)) 
                            | Some Tok_LessEqual -> let c = match_token a Tok_LessEqual in
                                        let (d,e) = relational_helper c in
                                        (d, Binop (LessEqual,b,e))
                            | Some Tok_GreaterEqual -> let f = match_token a Tok_GreaterEqual in
                                        let (g,h) = relational_helper f in
                                        (g, Binop (GreaterEqual,b,h))                       
                            | _ -> a, b

and additive_helper toks = let (a,b) = multiplicative_helper toks in
                            match lookahead a with
                            | Some Tok_Add -> let c = match_token a Tok_Add in
                                        let (d,e) = additive_helper c in
                                        (d, Binop (Add,b,e))
                            | Some Tok_Sub -> let f = match_token a Tok_Sub in
                                        let (g,h) = additive_helper f in
                                        (g, Binop (Sub,b,h))           
                            | _ -> a, b 
and multiplicative_helper toks = let (a,b) = concat_helper toks in
                                  match lookahead a with
                                  | Some Tok_Mult -> let c = match_token a Tok_Mult in
                                              let (d,e) = multiplicative_helper c in
                                              (d, Binop (Mult,b,e))
                                  | Some Tok_Div -> let f = match_token a Tok_Div in
                                              let (g,h) = multiplicative_helper f in
                                              (g, Binop (Div,b,h))           
                                  | _ -> a, b  
and concat_helper toks = let (a,b) = unary_helper toks in
                          match lookahead a with
                          | Some Tok_Concat -> let c = match_token a Tok_Concat in
                                      let (d,e) = concat_helper c in
                                      (d, Binop (Concat,b,e))
                          | _ -> a, b
and unary_helper toks = match lookahead toks with
                        | Some Tok_Not -> let a = match_token toks Tok_Not in
                                    let (b,c) = unary_helper a in
                                    (b, (Not(c)))
                        | _ -> functioncall_helper toks                 
and functioncall_helper toks = let (a,b) = primary_helper toks in
                                match lookahead a with
                                | Some Tok_Int _ -> let (p,q) = primary_helper a in (p, FunctionCall (b,q)) 
                                | Some Tok_String _ -> let (p,q) = primary_helper a in (p, FunctionCall (b,q)) 
                                | Some Tok_Bool _ -> let (p,q) = primary_helper a in (p, FunctionCall (b,q)) 
                                | Some Tok_ID _ -> let (p,q) = primary_helper a in (p, FunctionCall (b,q))    
                                | Some Tok_LParen -> let (p,q) = primary_helper a in (p, FunctionCall (b,q))                
                                | _ -> (a, b)

and primary_helper toks = match lookahead toks with
                            | Some Tok_Int i -> let a = match_token toks (Tok_Int i)  in
                                        (a, Value (Int i))
                            | Some Tok_String s -> let a = match_token toks (Tok_String s)  in
                                                   (a, Value (String s))
                            | Some Tok_Bool bb -> let a = match_token toks (Tok_Bool bb)  in
                                                   (a, Value (Bool bb))
                            | Some Tok_ID idd -> let a = match_token toks (Tok_ID idd)  in
                                                  (a, (ID idd))                      
                            | Some Tok_LParen -> let a = match_token toks (Tok_LParen)  in
                                                  let (p,q) = parse_expr a in
                                                  let b = match_token p (Tok_RParen)  in
                                                  (b,q)
                             | _ -> raise (InvalidInputException("parse_function_expr in primary_helper"))                    
and let_helper toks = let a = match_token toks Tok_Let in 
                      let (p,q) = recursions a in
                      let (b,c) = match lookahead p with
                      | Some Tok_ID i ->  let a = match_token p (Tok_ID i)  in
                                       (a, i)                              
                      | _ -> raise (InvalidInputException("parse_function_expr in let_helper")) in
                      let d = match_token b Tok_Equal in 
                      let (u,v) = parse_expr d in
                      let w = match_token u Tok_In in
                      let (r,s) = parse_expr w in 
                      (r, Let(c, q, v, s))     


and recursions toks = match lookahead toks with
                     | Some Tok_Rec -> let a = match_token toks (Tok_Rec) in 
                                        (a, true)
                     | _ -> (toks, false)

(* Part 3: Parsing mutop *)

let rec parse_mutop toks = match lookahead toks with
                            | Some Tok_DoubleSemi -> let a = match_token toks Tok_DoubleSemi in
                                                      (a, NoOp)
                                                      
                            | Some Tok_Def -> let a = match_token toks Tok_Def in
                                              let b = match (lookahead a) with
                                              | Some (Tok_ID i) -> i
                                              | _ -> raise (InvalidInputException("parse_function_mutop")) in
                                              let d = match_token a (Tok_ID b) in
                                              let c = match_token d Tok_Equal in
                                              let (p,q) = parse_expr c in
                                              let c = match_token p Tok_DoubleSemi in
                                              (c, (Def(b,q)))
                            | None -> raise (InvalidInputException("parse_function_mutop"))                  

                            | _ -> let (a,b) = parse_expr toks in 
                                  let p = match_token a Tok_DoubleSemi in
                                  (p,Expr(b))
                          
