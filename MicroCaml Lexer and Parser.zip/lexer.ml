(*Name: Ritika Munshi
UID: 118345048
*)

open TokenTypes

(* Part 1: Lexer - IMPLEMENT YOUR CODE BELOW *)

let tokenize input = 
  let rec tok position str =
    if position >= String.length str then
    []
      
    else if (Str.string_match (Str.regexp "=") str position) then
      Tok_Equal::(tok (position+1) str)
    else if (Str.string_match (Str.regexp "<>") str position) then
      Tok_NotEqual::(tok (position+2) str) 
    else if (Str.string_match (Str.regexp ">=") str position) then
      Tok_GreaterEqual::(tok (position+2) str) 
    else if (Str.string_match (Str.regexp "<=") str position) then
      Tok_LessEqual::(tok (position+2) str)
    else if (Str.string_match (Str.regexp "->") str position) then
      Tok_Arrow::(tok (position+2) str)
    else if (Str.string_match (Str.regexp ">") str position) then
      Tok_Greater::(tok (position+1) str)
    else if (Str.string_match (Str.regexp "<") str position) then
      Tok_Less::(tok (position+1) str)     
    
    else if (Str.string_match (Str.regexp "||") str position) then
      Tok_Or::(tok (position+2) str)
    else if (Str.string_match (Str.regexp "&&") str position) then
      Tok_And::(tok (position+2) str) 
    else if (Str.string_match (Str.regexp "not") str position) then
      Tok_Not::(tok (position+3) str)
    else if (Str.string_match (Str.regexp "if") str position) then
      Tok_If::(tok (position+2) str) 
    else if (Str.string_match (Str.regexp "then") str position) then
      Tok_Then::(tok (position+4) str) 
    else if (Str.string_match (Str.regexp "else") str position) then
      Tok_Else::(tok (position+4) str)    

    else if (Str.string_match (Str.regexp "[0-9]+") str position) then
      let token = Str.matched_string str in
      Tok_Int (int_of_string token)::(tok (position+ (String.length token)) str)
    else if (Str.string_match (Str.regexp "(\\-[0-9]+)") str position) then
      let token = Str.matched_string str in     
      Tok_Int (int_of_string (String.sub token (1) ((String.length token)-2)))::(tok (position+(String.length token)) str)
    
    else if (Str.string_match (Str.regexp "\\+") str position) then
      Tok_Add::(tok (position+1) str)
    else if (Str.string_match (Str.regexp "-") str position) then
      Tok_Sub::(tok (position+1) str)
    else if (Str.string_match (Str.regexp "\\*") str position) then
      Tok_Mult::(tok (position+1) str) 
    else if (Str.string_match (Str.regexp "/") str position) then
      Tok_Div::(tok (position+1) str)
    else if (Str.string_match (Str.regexp "\\^") str position) then
      Tok_Concat::(tok (position+1) str)
    
    else if (Str.string_match (Str.regexp "let") str position) then
      Tok_Let::(tok (position+3) str)
    else if (Str.string_match (Str.regexp "rec") str position) then
      Tok_Rec::(tok (position+3) str)
    else if (Str.string_match (Str.regexp "def") str position) then
      Tok_Def::(tok (position+3) str)
    else if (Str.string_match (Str.regexp "in") str position) then
      Tok_In::(tok (position+2) str)
    else if (Str.string_match (Str.regexp "fun") str position) then
      Tok_Fun::(tok (position+3) str)
    
    else if (Str.string_match (Str.regexp "true") str position) then
      Tok_Bool (true)::(tok (position+4) str)
    else if (Str.string_match (Str.regexp "false") str position) then
      Tok_Bool (false)::(tok (position+5) str)
  
    
    else if (Str.string_match (Str.regexp "\"[^\"]*\"") str position) then
      let token = Str.matched_string str in
      Tok_String ((String.sub token 1 ((String.length token)-2)))::(tok (position+(String.length token)) str)
    
    else if (Str.string_match (Str.regexp "[a-zA-Z][a-zA-Z0-9]*") str position) then
      let token = Str.matched_string str in
      Tok_ID (token)::(tok (position+(String.length token)) str)
    
    else if (Str.string_match (Str.regexp ";;") str position) then
      Tok_DoubleSemi ::(tok (position+2) str)

    else if (Str.string_match (Str.regexp ")") str position) then
      Tok_RParen ::(tok (position+1) str)
    else if (Str.string_match (Str.regexp "(") str position) then
      Tok_LParen::(tok (position+1) str)
    
    else if (Str.string_match (Str.regexp "\\|\n\\|\t") str position) then
      tok (position+1) str
    else
      raise (InvalidInputException "tokenize")
      in
      tok 0 input