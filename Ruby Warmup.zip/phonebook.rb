#Name: Ritika Munshi
#UID: 118345048

class PhoneBook
   
    def initialize
        @Hash_phonebook = Hash.new #created Hashmap which is our PhoneBook
    end

    def add(name, number, is_listed)
       #{name => [phone number, is_listed]}

        hash_values = Array.new

        #check if the person with that name exist
        if (@Hash_phonebook.has_key?(name)) then 
            return false
        end
        #check if the phone number is in the correct format
        if (number_valid_format(number) == false) 
            return false
        end
        #check if that specific number is listed
        @Hash_phonebook.each_key do |key|
            if (if_listed(number, is_listed, @Hash_phonebook) == true) 
                return false
            end
        end
        #check if the number exists and if it is listed
        @Hash_phonebook.each_key do |key|
            if (is_listed == true)
                if (if_listed(number, is_listed, @Hash_phonebook[key]) == true) 
                    return false
                end
            end
        end
        #if none of these apply would add to the phonebook
        hash_values.push(number)
        hash_values.push(is_listed)
        @Hash_phonebook[name] = hash_values

        return true     
    end

    #helper method for add
    def number_valid_format(number)
        number_array = Array.new
        number_array = number.split('')
        flag = false
        
        #NNN - NNN - NNNN
        #0123 3 456 7 891011
        if (number_array.length == 12) 
            if((number_array[0].to_i >= 1 && number_array[0].to_i <= 9) || (number_array[1].to_i >= 0 && number_array[1].to_i <= 9) || (number_array[2].to_i >= 0 && number_array[2].to_i <= 9) || (number_array[3] == '-') || (number_array[4].to_i >= 0 && number_array[4].to_i <= 9) || (number_array[5].to_i >= 0 && number_array[5].to_i <= 9) || (number_array[6].to_i >= 0 && number_array[6].to_i <= 9) || (number_array[7] == '-') || (number_array[8].to_i >= 0 && number_array[8].to_i <= 9) || (number_array[9].to_i >= 0 && number_array[9].to_i <= 9) || (number_array[10].to_i >= 0 && number_array[10].to_i <= 9) || (number_array[11].to_i >= 0 && number_array[11].to_i <= 9) ) 
                flag = true
            end
        else
            flag = false    
        end    
        return flag
    end

    #helper method for add
    def if_listed(number, is_listed, hash_list)
        list = false
        if (hash_list[0] == number)
            if (hash_list[1] == is_listed)
                list = true #want to add it
            else
                list = false #cannot add
            end
        end
        return list
    end

    def lookup(name)
        value = nil

        #if the name exist in the phonebook
        if (@Hash_phonebook.has_key?(name)) then 
            if (@Hash_phonebook[name][1] == true) #if it is listed
                value = @Hash_phonebook[name][0] #return the number
            else
                value = nil #if it is not listed return nil
            end
        end
        return value
    
    end

    def lookupByNum(number)
        value = nil

        #if the number exist in the phonebook
        @Hash_phonebook.each_key do |key|
            if ((@Hash_phonebook[key][0]).eql?(number)) then 
                if (@Hash_phonebook[key][1] == true) #if it is listed
                    value = key #return the name
                else
                    value = nil #if it is not listed return nil
                end
            end
        end
        return value

    end

    def namesByAc(areacode)
        name = Array.new #created a new array
        codes = Array.new #created a new array
        val = Array.new #created a new array

        #looping over the phonebook hash map
        @Hash_phonebook.each_key do |key|
            name = @Hash_phonebook.keys #array of names from the phonebook
            number = @Hash_phonebook[key][0] #phone number 
            area_val = number[0] + number[1] + number[2] #area code which is the first three numbers from the phone number
            codes.push(area_val) #adding the areacodes for the people in the array named codes
                 
        end

        #looping over the array named codes which has all the areacodes
        for i in 0..(codes.length)
            if (codes[i] == areacode) #check if there exist the areacode that we want in the array of all the areacodes
                val.push(name[i]) #if we find that areacode return the name of that specific person
            end
        end
        return val
    end


end
