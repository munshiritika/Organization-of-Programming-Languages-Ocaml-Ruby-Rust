# Name: Ritika Munshi
# UID: 118345048

def fib(n)
    array_fib = Array.new #created a new array
    for i in 0...n #looping to push elements into the array
       (array_fib.push(helper_fib(i))) 
    end 
    return array_fib

end

# Helper function for Fibonacci
def helper_fib(n)
    if (n <= 1) then
		return n
    else
		return (helper_fib(n-1)+helper_fib(n-2))
    end

end


def isPalindrome(n)
    # Converting into string
    n_in_string = n.to_s  
    # Reverse the value
    reverse_string = n_in_string.reverse
    # converting the reverse portion into integer
    num = reverse_string.to_i 

    if (n == num) then # comparing the value of n and the num which is the reverse of n
        return true
    else
        return false
    end
    
end

def nthmax(n, a)
    #length of the array
    len_a = a.length() 

    #created a new array
    sorted_array = Array.new 
    #sorting the array "a" in ascending order
    sorted_array = a.sort    

    if (n < len_a) then # n is less than the length of the array
        index = len_a - n - 1 
        value = sorted_array[index]  
        return value  # return value if is valid
    else
        return nil  # is n is greater than length of the array return nil
    end    

end

def freq(s)
    s_in_array = Array.new #create a new array
    s_in_array = s.split("") #store the string s in characters into the array

    s_hash = Hash.new #create a new hashmap

    val = ""
    # return empty string if the length of the s string is 0
    if (s_in_array.length() == 0)
        val = ""
    else
        for i in 0..(s_in_array.length-1) #looping over the array of characters
            if (s_hash.include?(s_in_array[i])) then #checking if the character already exists in the hashmap
                s_hash[s_in_array[i]] += 1 #update the hashmap
            else
                s_hash[s_in_array[i]] = 1 #add the character in the hashmao
            end
        end    
        values = Array.new #create a new array
    
        #adding the values of the hashmap into the new array named values
        s_hash.each_value do |value|
            values.push(value)
        end
    
        maximum = values.max #getting the maximum value which is the count
    
        #Return the character with the maximum counter or the frequency
        val = s_hash.key(maximum)

    end    
    return val

end

def zipHash(arr1, arr2)
    hash_map = Hash.new #create a new hashmap
    
    if (arr1.length() != arr2.length()) then #check if the length of arr1 and arr2 is same
        return nil #return nil if the length is different
    else    
        array_length = arr1.length() 
        for i in 0...array_length #loop over the array
            hash_map[arr1[i]] = arr2[i] #add values according to the key from arr1 and arr2
        end
    end 
    return hash_map

end

def hashToArray(hash)
    hash_key = Array.new #create a new array to store all key of hashmap
    hash_value = Array.new #create a new array to store all values of hashmap

    #store all the key of hashmap into the array named hash_key
    hash.each_key do |key|
        hash_key.push(key)
    end

    #store all the value of hashmap into the array named hash_value
    hash.each_value do |value|
        hash_value.push(value)
    end

    #returning by using the zip method to combine the array hash_key and hash_value to form a 2-D array
    return (hash_key.zip(hash_value))
   
end
