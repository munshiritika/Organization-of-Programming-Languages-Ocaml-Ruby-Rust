(*Name: Ritika Munshi
UID: 118345048
*)

open MicroCamlTypes
open Utils

exception TypeError of string
exception DeclareError of string
exception DivByZeroError 

(* Provided functions - DO NOT MODIFY *)

(* Adds mapping [x:v] to environment [env] *)
let extend env x v = (x, ref v)::env

(* Returns [v] if [x:v] is a mapping in [env]; uses the
   most recent if multiple mappings for [x] are present *)
let rec lookup env x =
  match env with
  | [] -> raise (DeclareError ("Unbound variable " ^ x))
  | (var, value)::t -> if x = var then !value else lookup t x

(* Creates a placeholder mapping for [x] in [env]; needed
   for handling recursive definitions *)
let extend_tmp env x = (x, ref (Int 0))::env

(* Updates the (most recent) mapping in [env] for [x] to [v] *)
let rec update env x v =
  match env with
  | [] -> raise (DeclareError ("Unbound variable " ^ x))
  | (var, value)::t -> if x = var then (value := v) else update t x v
        
(* Part 1: Evaluating expressions *)

(* Evaluates MicroCaml expression [e] in environment [env],
   returning a value, or throwing an exception on error *)
let rec eval_expr env e = match e with
                          | Value a -> a

                          | ID variable -> let a = lookup env variable in a

                          | Not n -> let a = eval_expr env n in 
                                     if (a = Bool true) then Bool false 
                                     else Bool true

                          | Binop (op, e1, e2) -> let n1 = e1 in 
                                                  let n2 = e2 in
                                                  (match op with
                                                  | Add -> let a = eval_expr env n1 in 
                                                           let b = eval_expr env n2 in
                                                            (match a with 
                                                            | Int n1 -> (match b with
                                                                        | Int n2 -> Int (n1 + n2) 
                                                                        | _ -> raise (TypeError "Expected type int") )
                                                            | _ -> raise (TypeError "Expected type int") ) 

                                                  | Sub -> let a = eval_expr env n1 in 
                                                           let b = eval_expr env n2 in
                                                           (match a with 
                                                            | Int n1 -> (match b with
                                                                        | Int n2 -> Int (n1 - n2)
                                                                        | _ -> raise (TypeError "Expected type int") )
                                                            | _ -> raise (TypeError "Expected type int") )

                                                  | Mult -> let a = eval_expr env n1 in 
                                                            let b = eval_expr env n2 in
                                                            (match a with 
                                                            | Int n1 -> (match b with
                                                                        | Int n2 -> Int (n1 * n2)
                                                                        | _ -> raise (TypeError "Expected type int") )
                                                            | _ -> raise (TypeError "Expected type int") )

                                                  | Div -> let a = eval_expr env n1 in 
                                                           let b = eval_expr env n2 in
                                                            (match a with 
                                                            | Int n1 -> (match b with
                                                                        | Int n2 -> if (n2 <> 0) then (Int (n1/n2))
                                                                                    else raise (DivByZeroError)
                                                                        | _ -> raise (TypeError "Expected type int") )
                                                            | _ -> raise (TypeError "Expected type int") )

                                                  | Greater -> let a = eval_expr env n1 in 
                                                               let b = eval_expr env n2 in
                                                               (match a with 
                                                               | Int n1 -> (match b with
                                                                           | Int n2 -> if (n1 > n2) then Bool true 
                                                                                       else Bool false
                                                                           | _ -> raise (TypeError "Expected type int") )
                                                               | _ -> raise (TypeError "Expected type int") )

                                                  | Less -> let a = eval_expr env n1 in 
                                                            let b = eval_expr env n2 in
                                                            (match a with 
                                                            | Int n1 -> (match b with
                                                                        | Int n2 -> if (n1 < n2) then Bool true 
                                                                                    else Bool false
                                                                        | _ -> raise (TypeError "Expected type int") )
                                                            | _ -> raise (TypeError "Expected type int") )
                                                            
                                                  | GreaterEqual -> let a = eval_expr env n1 in 
                                                                    let b = eval_expr env n2 in
                                                                    (match a with 
                                                                    | Int n1 -> (match b with
                                                                                | Int n2 -> if (n1 >= n2) then Bool true
                                                                                            else Bool false
                                                                                | _ -> raise (TypeError "Expected type int") )
                                                                    | _ -> raise (TypeError "Expected type int") )

                                                  | LessEqual -> let a = eval_expr env n1 in 
                                                                 let b = eval_expr env n2 in
                                                                 (match a with 
                                                                 | Int n1 -> (match b with
                                                                             | Int n2 -> if (n1 <= n2) then Bool true 
                                                                                         else Bool false
                                                                             | _ -> raise (TypeError "Expected type int") )
                                                                 | _ -> raise (TypeError "Expected type int") )

                                                  | Concat -> let a = eval_expr env n1 in 
                                                              let b = eval_expr env n2 in
                                                            (match a with 
                                                            | String n1 -> (match b with
                                                                        | String n2 -> String (n1 ^ n2)
                                                                        | _ -> raise (TypeError "Expected type string") )
                                                            | _ -> raise (TypeError "Expected type string") )

                                                  | Equal -> let a = eval_expr env n1 in 
                                                             let b = eval_expr env n2 in
                                                                  (match a with 
                                                                  | Int n1 -> (match b with
                                                                              | Int n2 -> if (n1 = n2) then Bool true
                                                                                          else Bool false
                                                                              | _ -> raise (TypeError "Cannot compare types") )
                                                                  | String n1 -> (match b with
                                                                              | String n2 -> if (n1 = n2) then Bool true 
                                                                                            else Bool false
                                                                              | _ -> raise (TypeError "Cannot compare types") )
                                                                  | Bool n1 -> (match b with
                                                                              | Bool n2 -> if (n1 = n2) then Bool true 
                                                                                           else Bool false
                                                                              | _ -> raise (TypeError "Cannot compare types") )
                                                                  | _ -> raise (TypeError "Invalid type") )

                                                  | NotEqual -> let a = eval_expr env n1 in 
                                                                let b = eval_expr env n2 in
                                                                (match a with 
                                                                | Int n1 -> (match b with
                                                                            | Int n2 -> if (n1 <> n2) then Bool true 
                                                                                        else Bool false
                                                                            | _ -> raise (TypeError "Cannot compare types") )
                                                                | String n1 -> (match b with
                                                                            | String n2 -> if (n1 <> n2) then Bool true 
                                                                                           else Bool false
                                                                            | _ -> raise (TypeError "Cannot compare types") )
                                                                | Bool n1 -> (match b with
                                                                            | Bool n2 -> if (n1 <> n2) then (Bool true) 
                                                                                         else Bool false
                                                                            | _ -> raise (TypeError "Cannot compare types") )
                                                                | _ -> raise (TypeError "Invalid type") )

                                                  | Or -> let a = eval_expr env n1 in 
                                                          let b = eval_expr env n2 in
                                                          (match a with 
                                                          | Bool n1 -> (match b with
                                                                      | Bool n2 -> if (n1 || n2) then Bool true 
                                                                                   else Bool false
                                                                      | _ -> raise (TypeError "Expected type bool") )
                                                          | _ -> raise (TypeError "Expected type bool") )

                                                  | And -> let a = eval_expr env n1 in 
                                                           let b = eval_expr env n2 in
                                                           (match a with 
                                                            | Bool n1 -> (match b with
                                                                        | Bool n2 -> if (n1 && n2) then Bool true
                                                                                     else Bool false
                                                                        | _ -> raise (TypeError "Expected type bool") )
                                                            | _ -> raise (TypeError "Expected type bool") ) )

                          | If (exp1, exp2, exp3) -> let a = eval_expr env exp1 in
                                                    (match a with
                                                     | Bool b -> if (a = (Bool true)) then eval_expr env exp2
                                                                 else eval_expr env exp3
                                                     | _ -> raise (TypeError "Boolean only"))                                                    

                          | Let (variable, recur, exp1, exp2) -> if (recur = false) then 
                                                                 let a = eval_expr env exp1 in
                                                                 let new_env = extend env variable a in
                                                                 eval_expr new_env exp2
                                                                 else                                                                       
                                                                    let temp_env = extend_tmp env variable in
                                                                    let b = eval_expr temp_env exp1 in
                                                                    update temp_env variable b;
                                                                    eval_expr temp_env exp2 

                          | Fun (variable, exp) -> Closure (env, variable, exp)

                          | FunctionCall (exp1, exp2) -> let a = eval_expr env exp1 in 
                                                         let b = eval_expr env exp2 in
                                                         (match a with
                                                         | Closure (enviro, vari, expres) -> let new_envi = extend enviro vari b in 
                                                                                             eval_expr new_envi expres
                                                         | _ -> raise (TypeError "Not a function call") )
                                                        
                       
                          

(* Part 2: Evaluating mutop directive *)

(* Evaluates MicroCaml mutop directive [m] in environment [env],
   returning a possibly updated environment paired with
   a value option; throws an exception on error *)
let eval_mutop env m = 
                      match m with
                       | NoOp -> (env, None)
                       | Def (var,exp) -> let temp_envir = extend_tmp env var in 
                                          let c = eval_expr temp_envir exp in                                              
                                          update temp_envir var c;
                                          (temp_envir, Some (c))
                       | Expr exp -> let a = eval_expr env exp in
                                     (env, Some (a)) 
                      