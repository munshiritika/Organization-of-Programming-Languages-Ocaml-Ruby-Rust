(*Name: Ritika Munshi
  UID: 118345048
*)
open Funs

(*************************************)
(* Part 2: Three-Way Search Tree *)
(*************************************)

type int_tree =
  | IntLeaf
  | IntNode of int * int option * int_tree * int_tree * int_tree 

let empty_int_tree = IntLeaf

let rec int_insert x t =
  match t with
  | IntLeaf -> IntNode (x, None, IntLeaf, IntLeaf, IntLeaf)         (*when its intleaf it wont point to anything*)
  | IntNode (first, second, third, fourth, fifth) -> 
    let matching = match second with                                (*matching over second which is int option of IntNode*)
          | None -> -1                                              (*if second is None then would return -1*)
          | Some a -> a                                             (*else would return in the varible a which is basically integer*)
          in 
        if (x = first && second <> None)                            (*if x already exist in the first and second is not none*)
          then t                                                    (*return t as it unchanged*)
        else if (x = first && second = None)                        (*if x already exist in the first and second is none*)
          then t  
        else if x = matching                                        (*if x exist in the second*)
            then t  
        else if (second = None) then                                (*if second is none we have to check as we store them*)
          (if(x > first)                                            (*if x is greater than first then would store in second*)
            then IntNode (first, Some x, IntLeaf, IntLeaf, IntLeaf)
          else 
            IntNode (x, Some first, IntLeaf, IntLeaf, IntLeaf))     (*else store in first and store what first has in second*)
        else
          if (x > first && x < matching)                            (*x is between the first and second*)
            then let store = int_insert x fourth in IntNode (first, second, third, store, fifth)
          else if (x < first)                                       (*x is less than first*)
            then let store = int_insert x third in IntNode (first, second, store, fourth, fifth)
          else if (x > matching)                                    (*x is greater than second*)
            then let store = int_insert x fifth in IntNode (first, second, third, fourth, store)
          else 
            t                                                       (*else return the tree with first and second as it is*)
          

let rec int_mem x t = 
  match t with
  | IntLeaf -> false     
  | IntNode (first, second, third, fourth, fifth) ->
    let matching = match second with                                (*matching over second which is int option of IntNode*)
          | None -> -1                                              (*if second is None then would return -1*)
          | Some a -> a                                             (*else would return in the varible a which is basically integer*)
          in
          if (x = first || x = matching)                            (*if x is equal to first or x is equal to matching which is our second then return true*)
            then true
          else
            if (x > first && x < matching)                          (*x is between the first and second*)
            then int_mem x fourth
          else if (x < first)                                       (*x is less than first*)
            then int_mem x third
          else if (x > matching)                                    (*x is greater than second*)
            then int_mem x fifth
          else 
            false 

let rec int_size t = 
  match t with
  | IntLeaf -> 0     
  | IntNode (first, second, third, fourth, fifth) ->
     match second with                                                             (*matching over second which is int option of IntNode*)
          | None -> 1                                                              (*if second is none then the size would just be 1 as its just first*)
          | Some a -> 2 + (int_size third) + (int_size fourth) +  (int_size fifth) (*if second is not none then recursively we have to count all the elements of subtrees*) 
        
      
let rec int_max t =
  match t with
  | IntLeaf -> raise (Invalid_argument("int_max"))                                 (*throwing an exception if Intleaf meaning empty*)
  | IntNode (first, None, third, fourth, fifth) -> first                           (*return first when second is none*)
  | IntNode (first, Some a, third, fourth, fifth) -> if (fifth <> IntLeaf)         (*recursively check for the second until intleaf is empty*)
                                                      then int_max fifth
                                                    else a
    


(*******************************)
(* Part 3: Three-Way Search Tree-Based Map *)
(*******************************)

type 'a tree_map =
  | MapLeaf
  | MapNode of (int * 'a) * (int * 'a) option * 'a tree_map * 'a tree_map * 'a tree_map 

let empty_tree_map = MapLeaf

let rec map_put k v t = 
  match t with
  | MapLeaf -> MapNode((k,v), None, MapLeaf, MapLeaf, MapLeaf)                                                                               
  | MapNode ((left_key,left_value), right_node, left, middle, right) ->  
          match right_node with                                                          (*matching over the right_node which is the option*)
          | None ->                                                                      (*if right_node is NONE*)
              if(k > left_key)                                                           (*if k is greater than than the left_key*)                             
                then MapNode ((left_key,left_value), Some (k,v), MapLeaf, MapLeaf, MapLeaf)
              else if (k < left_key)                                                     (*if k is less than than the left_key*) 
                then MapNode ((k,v), Some (left_key,left_value), MapLeaf, MapLeaf, MapLeaf)
              else           
                raise (Invalid_argument("map_put"))                                     (*throw an exception if k is equal to the left_key*)                                         
          | Some (a,b) ->                                                               (*if right_node is NOT NONE*)                                            
              if (k = a)                                                                (*if equal throw an exception*)                                                                           
                then raise (Invalid_argument("map_put"))  
              else if (k > a)                                                           (*if its greater, has to go to the right of the tree*)                                                                       
                then let store = map_put k v right in MapNode ((left_key,left_value), right_node, left, middle, store)    
              else if (k < a && k > left_key)                                           (*if its in the middle, has to go to the center*)                                                                       
                then let store = map_put k v middle in MapNode ((left_key,left_value), right_node, left, store, right)
              else if (k = left_key)                                                    (*if its equal to the key of left node then thorw an error*)
                then raise (Invalid_argument("map_put"))
              else                                                                      (*has to go to the left of the tree*)
                let store = map_put k v left in MapNode ((left_key,left_value), right_node, store, middle, right)                                   

let rec map_contains k t = 
  match t with
  | MapLeaf -> false                                    (*return false for MapLeaf*)                                           
  | MapNode ((a,b), value, left, middle, right) ->                                                     
              if (value = None)                         (*if value which is the right node is None then return false*)
                then false
              else if (a = k)                           (*if its equal to the key of left node then return true*)
                then true
              else                                      (*if right node which is value is NOT NONE*)
                let (aa,bb) =                           (*tuple which has the key and value for the right node*)
                  match value with
                    | None -> raise (Invalid_argument("error"))
                    | Some (p,q) -> (p,q)
                in
                  if (k < a)                            (*if its less than then goes recursively to the left side of the tree*)
                    then map_contains k left
                  else if (k > a && k < aa)             (*if its in the middle its goes to the center of the tree*)
                    then map_contains k middle
                  else if (k > aa)                      (*if its greater then goes recursively to the right side of the tree*)
                    then map_contains k right
                  else if (k = aa)                      (*if its equal then return true*)
                    then true
                  else                                  (*if none applies return false*)
                    false

let rec map_get k t =
  match t with
  | MapLeaf -> raise (Invalid_argument("map_get"))      (*return exception error for MapLeaf*)                                                                            
  | MapNode ((a,b), value, left, middle, right) -> 
                if (a = k)                              (*if its equal to the key of left node then return b which is value*)
                  then b
                else
                let (matchinga, matchingb) =            (*tuple which has the key and value for the right node*)
                  match value with
                    | None -> raise (Invalid_argument("map_get")) 
                    | Some (p,q) -> (p,q)
                in
                  if (k < a)                            (*if its less than then goes recursively to the left side of the tree*)
                    then map_get k left
                  else if (k > a && k < matchinga)      (*if its in the middle its goes to the center of the tree*)
                    then map_get k middle
                  else if (k > matchinga)               (*if its greater then goes recursively to the right side of the tree*)
                    then map_get k right
                  else if (k = matchinga)               (*if its equal then return value*)
                    then matchingb
                  else 
                    raise (Invalid_argument("map_get"))  (*if none applies return error*)
           

  

(***************************)
(* Part 4: Variable Lookup *)
(***************************)

(* Modify the next line to your intended type *)
type lookup_table = (*
|Somes of int
|Somess of string
|So of (int * string) list *)
(string * int) list list                                            (*Type is basically a list of list which has tuples of string and integer*)

let empty_table : lookup_table = []                                 (*Return an empty list*)

let push_scope (table : lookup_table) : lookup_table = []::table    (*push into the table*)

let pop_scope (table : lookup_table) : lookup_table =
      match table with                                              (*Match over the table*)
      | [] -> failwith "No scopes remain!"                          (*Throw an error is its an empty list or with no scopes*)
      | h::t -> t                                                   (*Return the elements except the last pushed element which has to be popped*)

  (*Helper function for add_var function which looks for each and every scope*)
  let rec add_var_helper name scope =
    match scope with                                                (*match over the scope because scope itself is a list with tuples in it*)
    | [] -> false                                                   (*return false if its an empty list or empty scope*)
    | h::t -> 
        let (a,b) = h                                               (*h has the string value*)
        in
          if (a = name)                                             (*if the name is found in the scope then return true*)
            then true
          else 
            add_var_helper name t                                   (*else call recursively over the scopes we have in the list*)


let add_var name value (table : lookup_table) : lookup_table =
  match table with                                                  (*match over the table*)
  | [] -> failwith "There are no scopes to add a variable to!"      (*throw an error if no scopes exist*)
  | h::t -> if (add_var_helper name h = false)                      (*if the scope exist call helper function and check if false then meaning we will add into the list of scope*)
              then ((name, value)::h)::t
            else 
              failwith "Duplicate variable binding in scope!"       (*else will throw error because we cannot have duplicates*)

  (*Helper function for loopup function which recursively checks for all the scopes*)
  let rec lookup_helper name scope =
    match scope with                                                (*match over the scope which is the list of tuples*)
    | [] -> failwith "Variable not found!"                          (*throw an error if the variable is not found*)
    | h::t -> 
        let (a,b) = h                                               (*h has the string value*)
        in
          if (a = name)                                             (*if the name is found in the scope then return the value associated with it*)
            then b
          else 
            lookup_helper name t                                    (*else call the function recursively*)

let rec lookup name (table : lookup_table) =
  match table with                                                  (*match over the table*)
  | [] -> failwith "Variable not found!"                            (*throw an error if the variable is not found*)
  | h::t -> if (add_var_helper name h = true)                       (*if the scope exist call helper function and check if false then meaning we will call lookup_helper function to look over the list of scopes*)
              then lookup_helper name h
            else 
              lookup name t                                         (*else will call the function recusively*)