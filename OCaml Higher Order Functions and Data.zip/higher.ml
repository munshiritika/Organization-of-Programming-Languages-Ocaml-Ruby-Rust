(*Name: Ritika Munshi
  UID: 118345048
*)

open Funs

(********************************)
(* Part 1: High Order Functions *)
(********************************)

(*Returns true if e is present in the list lst, and false if it is not.*)
let contains_elem lst e = 
  let boolean = false in
  let value = 
    fold (fun boolean x -> if (e = x) 
                            then true 
                          else 
                            if (boolean = true) 
                              then true 
                            else false) 
    (boolean) lst in value


(*Returns a list of the same length as lst which has a 1 at each position 
  in which the corresponding position in lst is equal to x, and a 0 otherwise.*)
let is_present lst x = 
  if (lst = []) 
    then [] 
  else
    map (fun a -> if (a = x) 
                    then 1 
                  else 0) lst         

(*Returns how many elements in lst are equal to target.*)
let count_occ lst target =
  let count = 0 in
  let value = 
    fold (fun count x -> if (target = x) 
                            then (count+1) 
                          else 
                            count) 
    (count) lst in value

(*Given a list, returns a list with all duplicate elements removed. 
  Order does not matter, in the output list.*)
let uniq lst = 
  if (lst = []) 
    then [] 
  else
    fold (fun lstt_acc y -> if (contains_elem lstt_acc y = true) 
                              then lstt_acc
                            else y::lstt_acc) ([]) lst           

(*Given a list, returns a list of pairs where the first integer represents the element of the list 
  and the second integer represents the number of occurrences of that element in the list. 
  This associative list should not contain duplicates. Order does not matter, in the output list.*)
let assoc_list lst = 
  (* use uniq function and count occ function*) 
  if (lst = []) 
    then [] 
  else
    let unique = uniq lst in
    fold (fun a y -> let count =  count_occ lst y in
                     (y,count)::a) ([]) unique


(*Applies each function in fns to each argument in args in order, collecting all results in a single list.*)
let ap fns args =
    let value = 
      fold (fun a x -> a @ map x args) ([]) 
      fns in value 
